<img src="./GitHub Project Title Image.png">

# food_truck_finder

Mobile application development project made by using Flutter and Firebase.
