import 'package:flutter/material.dart';

Color truckblackColor = Color(0xff221e1f);
Color skyorangeColor = Color(0xffe35225);
Color sunyellowColor = Color(0xfff5b618);
Color applegreenColor = Color(0xFF78C200);
Color lightgreyColor = Colors.grey[100];

Color primaryColor = Color(0xffe35225);
